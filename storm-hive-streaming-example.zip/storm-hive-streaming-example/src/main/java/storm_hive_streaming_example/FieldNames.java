package storm_hive_streaming_example;

/**
 * Created by hkropp on 25/09/15.
 */
public class FieldNames
{

    public static final String STOCK_FIELD = "stock";
}
